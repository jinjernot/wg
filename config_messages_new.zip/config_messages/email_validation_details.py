EMAIL_ACCOUNT_DETAILS = {

    "Roberto Quintero": {
        "name_oxxo": "Roberto Alejandro",
        "name_scotiabank": "Alejandro Quintero Montoya Roberto",
        "name_banco_azteca": "Roberto Quintero",
        "name_receipt": ["Roberto", "ROBERTO", "Alejandro", "Quintero"]
    },

    "Jonathan Correa": {
        "name_oxxo": "jonathan",
        "name_scotiabank": "Jonathan Correa", 
        "name_banco_azteca": "Jonathan Correa", 
        "name_receipt": ["jonathan", "john", "correa"]
    },

    "Jonathan Becerra": {
        "name_oxxo": "jonathan",
        "name_scotiabank": "Jonathan Becerra",
        "name_banco_azteca": "Jonathan Becerra", 
        "name_receipt": ["jonathan", "john", "becerra"]
    },

    "Eduardo Ramirez": {
        "name_oxxo": "EDUARDO RAMIREZ LAUREANO",
        "name_scotiabank": "Ramirez Laureano Eduardo",
        "name_banco_azteca": "EDUARDO RAMIREZ LAUREANO",
        "name_receipt": ["EDUARDO RAMIREZ", "EDUARDO R", "LAUREANO"]
    },

    "Victor Melchor": {
        "name_oxxo": "Victor Melchor", 
        "name_scotiabank": "Victor Melchor", 
        "name_banco_azteca": "Victor Melchor", 
        "name_receipt": ["Victor", "Melchor", "VICTOR"]
    }
}